# Repeat Prototyping Steps on Prototyping Board in IRL

Status: Not started
Task ID: KIH-60

## Description

-