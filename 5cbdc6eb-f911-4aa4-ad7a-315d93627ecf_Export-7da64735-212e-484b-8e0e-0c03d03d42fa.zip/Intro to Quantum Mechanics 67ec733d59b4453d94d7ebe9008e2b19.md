# Intro to Quantum Mechanics

Assignee: Timothy Ka
Status: Not started
Project: Modern Physics (https://www.notion.so/Modern-Physics-f74a4820ec6b45f6b7166faf5fa93607?pvs=21)
Sprint: Sprint 3 (https://www.notion.so/Sprint-3-39c193cdb5dc455c876dba6dd0727cc0?pvs=21)
Priority: High
Task ID: KIH-10

## Description

-