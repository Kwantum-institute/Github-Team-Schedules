# Feature Request

Status: Not started

## **Description**

[Description of feature request]

## User problem

[Describe the problem this feature will solve]

## Screenshots / GIFs / Videos

[https://www.notion.so](https://www.notion.so)

[https://www.notion.so](https://www.notion.so)

## Additional Notes

[Add anything else that might be helpful]