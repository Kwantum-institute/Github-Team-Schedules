# Uncensored GPT

Assignee: Shadow 1103
Status: In progress
Project: Adrian’s Blog (https://www.notion.so/Adrian-s-Blog-a567e68887e84a398b9da2ac781add13?pvs=21)
Sub-tasks: finish setup of Wen Ui (finish%20setup%20of%20Wen%20Ui%209655297c72a74f0a801c04e240bf0443.md), Finish learning and implementing hugging face model on VS code/Git  (Finish%20learning%20and%20implementing%20hugging%20face%20mode%2023c95175f28d4fa4b73947cc3e24ec4e.md), Stable LM and package installation/ embedding into VS code (Stable%20LM%20and%20package%20installation%20embedding%20into%20%2049c0cd85fcda454d9dff55b866bfec7f.md), Finish training and supervised learning  (Finish%20training%20and%20supervised%20learning%20336c43ab956f4935b3df70d64b9f5b21.md), Old Lenovo tablet as touch monitor and external processor for Raspberry Pi 5 (Old%20Lenovo%20tablet%20as%20touch%20monitor%20and%20external%20pr%2097d99dee698548ff923e1c3ec76b55d5.md)
Task ID: KIH-165

## Description

- [https://youtu.be/BntGOaMrB90?si=mMznJ-vXiY6nQdTn](https://youtu.be/BntGOaMrB90?si=mMznJ-vXiY6nQdTn)