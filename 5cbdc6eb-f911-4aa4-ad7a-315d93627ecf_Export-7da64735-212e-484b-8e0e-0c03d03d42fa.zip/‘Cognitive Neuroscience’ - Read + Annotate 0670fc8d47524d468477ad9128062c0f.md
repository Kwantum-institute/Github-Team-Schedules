# ‘Cognitive Neuroscience’ - Read + Annotate

Assignee: Bonnie Wong
Status: Not started
Due: February 15, 2024
Parent-task: General Research Stage 1 (General%20Research%20Stage%201%20184a53b7bed44dbea4608c4e2f656623.md)
Priority: Medium
Task ID: KIH-34

## Description

-