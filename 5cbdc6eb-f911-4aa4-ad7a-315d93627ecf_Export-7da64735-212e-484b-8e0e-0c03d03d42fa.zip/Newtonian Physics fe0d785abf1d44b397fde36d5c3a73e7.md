# Newtonian Physics

Assignee: Timothy Ka
Status: Not started
Summary: This document provides instructions for adding a new task to a task tracking system. The task ID, assignee, status, due date, priority, and tags can be customized for each task.
Due: March 10, 2024
Project: Modern Physics (https://www.notion.so/Modern-Physics-f74a4820ec6b45f6b7166faf5fa93607?pvs=21)
Sprint: Sprint 2 (https://www.notion.so/Sprint-2-0caf9fc61dd344c199c130291f4008e0?pvs=21)
Priority: Low
Task ID: KIH-1

- Ready to start tracking your tasks here? Start by clicking the blue “New” button at the top right of your table.
- Customize each task by populating the fields above, such as the task’s assignee, due date, and status.