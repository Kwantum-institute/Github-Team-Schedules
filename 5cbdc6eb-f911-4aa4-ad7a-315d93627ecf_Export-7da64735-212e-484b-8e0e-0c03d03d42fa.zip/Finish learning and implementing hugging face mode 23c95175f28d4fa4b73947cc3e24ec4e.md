# Finish learning and implementing hugging face model on VS code/Git

Assignee: Shadow 1103
Status: Not started
Parent-task: Uncensored GPT (Uncensored%20GPT%2088e7ff2ef7e74fb7ac1d7e9cd139af72.md)
Task ID: KIH-167

## Description

-