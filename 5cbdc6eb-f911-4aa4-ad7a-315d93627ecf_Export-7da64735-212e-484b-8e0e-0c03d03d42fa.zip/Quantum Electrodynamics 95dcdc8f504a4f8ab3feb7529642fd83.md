# Quantum Electrodynamics

Assignee: Timothy Ka
Status: Not started
Project: Modern Physics (https://www.notion.so/Modern-Physics-f74a4820ec6b45f6b7166faf5fa93607?pvs=21)
Sprint: Sprint 2 (https://www.notion.so/Sprint-2-0caf9fc61dd344c199c130291f4008e0?pvs=21)
Priority: Medium
Task ID: KIH-15

## Description

-