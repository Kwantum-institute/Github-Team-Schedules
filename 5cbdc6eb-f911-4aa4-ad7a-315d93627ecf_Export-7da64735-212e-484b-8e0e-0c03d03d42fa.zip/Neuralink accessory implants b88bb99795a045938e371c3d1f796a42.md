# Neuralink accessory implants

Status: In progress
Parent-task: Neuralink and EMR/ mkultra Article   (Neuralink%20and%20EMR%20mkultra%20Article%2021a8fedc7da340748daa5698bd4b08b8.md)
Task ID: KIH-154

## Description

- Bone reinforcement:
    - [https://www.imperial.ac.uk/news/235556/kisspeptin-hormone-enhance-human-bone-activity/](https://www.imperial.ac.uk/news/235556/kisspeptin-hormone-enhance-human-bone-activity/)
    
    Natural Silicon produced by human Body and Titanium is inert and is not rejected by human body
    
    - [https://www.sciencedirect.com/science/article/pii/S2238785422000874](https://www.sciencedirect.com/science/article/pii/S2238785422000874)