# ‘Amyloid-β Peptide Protects Against Microbial Infection In Mouse and Worm Models of Alzheimer’s Disease’ - Pick, Read, Annotate on iPad

Assignee: Bonnie Wong
Status: Not started
Parent-task: General Research Stage 1 (General%20Research%20Stage%201%20184a53b7bed44dbea4608c4e2f656623.md)
Priority: Low
Task ID: KIH-37

## Description

- Website: [file:///C:/Users/Bonnie/Documents/Bonnie's%20Home/Study%20Room/School/IYNA%20-%20Neuroscience/IYNA%20Journal%20Club/Amyloid-%CE%B2%20Peptide%20Protects%20Against%20Microbial%20Infection%20In%20Mouse%20and%20Worm%20Models%20of%20Alzheimer%E2%80%99s%20Disease%20-%20PMC%20(IYNA%20Journal%20Club%20Feb).pdf](file:///C:/Users/Bonnie/Documents/Bonnie's%20Home/Study%20Room/School/IYNA%20-%20Neuroscience/IYNA%20Journal%20Club/Amyloid-%CE%B2%20Peptide%20Protects%20Against%20Microbial%20Infection%20In%20Mouse%20and%20Worm%20Models%20of%20Alzheimer%E2%80%99s%20Disease%20-%20PMC%20(IYNA%20Journal%20Club%20Feb).pdf)

[NCBI - WWW Error Blocked Diagnostic](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5505565/)

## Tips

- Basically we looked at all figures of the research paper, and analysed them(what is statistical signigicance, why entrapment micrographs are important for biological understanding etc ). Then proposed what we could do with that unformation that paper gave us.
- We didn't read anything actually, we only analyzed the most crucial part - micrograph pics, graphs/plots of statistics
    - Because apparently by looking at evidence you understand what the paper is trying to say

- **Ideas how we could implement the information**
    - i.e new treatment that utilizes the properties of aggregation to dislodge all the A-beta from the brain preventing further neurodegenerative damage
    - That was my idea. But overall it was pretty quick and easy

## Time limit

- 30-45 mins.