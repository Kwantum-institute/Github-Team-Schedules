# Recreate Basic Sub-Assemblies with Breadboard

Status: In progress
Task ID: KIH-67

## Description

-