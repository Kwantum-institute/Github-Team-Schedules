# EMR and biocomputers

Status: In progress
Project: Adrian’s Blog (https://www.notion.so/Adrian-s-Blog-a567e68887e84a398b9da2ac781add13?pvs=21)
Parent-task: Neuralink and EMR/ mkultra Article   (Neuralink%20and%20EMR%20mkultra%20Article%2021a8fedc7da340748daa5698bd4b08b8.md)
Task ID: KIH-49

## Description

- [https://www.frontiersin.org/news/2023/02/28/brain-organoids-intelligence-biocomoputing-hartung/](https://www.frontiersin.org/news/2023/02/28/brain-organoids-intelligence-biocomoputing-hartung/)
- [https://www.youtube.com/results?search_query=human+stem+cells+on+computer](https://www.youtube.com/results?search_query=human+stem+cells+on+computer)

EMR on human brains:

- [https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7053547/](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7053547/)
    - The human brain functions in a state of superposition between particle and wave form
    - Proposed: String Theory and Quantum physics at the same time
- [https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6513191/](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6513191/)
    - EMR waves or sound frequencies such as binaural beats and the solfflegio frequencies have been found to help with cognitive and concentration performances
    -