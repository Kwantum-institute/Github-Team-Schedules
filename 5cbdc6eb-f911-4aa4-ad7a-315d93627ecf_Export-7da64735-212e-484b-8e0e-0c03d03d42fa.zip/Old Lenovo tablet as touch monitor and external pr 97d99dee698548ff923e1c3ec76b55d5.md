# Old Lenovo tablet as touch monitor and external processor for Raspberry Pi 5

Assignee: Shadow 1103
Status: In progress
Parent-task: Uncensored GPT (Uncensored%20GPT%2088e7ff2ef7e74fb7ac1d7e9cd139af72.md)
Task ID: KIH-172

## Description

- [https://youtu.be/nui8kXvUAys?si=4HU7ZWT6aW1tSLJa](https://youtu.be/nui8kXvUAys?si=4HU7ZWT6aW1tSLJa)
- [https://community.element14.com/products/raspberry-pi/f/forum/49687/connecting-dead-laptop-android-tablet-displays-to-raspberry-pi#:~:text=Every display comes with a,logic level to work correctly](https://community.element14.com/products/raspberry-pi/f/forum/49687/connecting-dead-laptop-android-tablet-displays-to-raspberry-pi#:~:text=Every%20display%20comes%20with%20a,logic%20level%20to%20work%20correctly).
- [https://www.tomshardware.com/how-to/control-raspberry-pi-5-gpio-with-python-3](https://www.tomshardware.com/how-to/control-raspberry-pi-5-gpio-with-python-3)
    - Breadboard
    - Arduino attachement
    - [https://www.audiocom.hk/products/card-sandisk-ultra-microsd](https://www.audiocom.hk/products/card-sandisk-ultra-microsd)
    - WCL: 100oml