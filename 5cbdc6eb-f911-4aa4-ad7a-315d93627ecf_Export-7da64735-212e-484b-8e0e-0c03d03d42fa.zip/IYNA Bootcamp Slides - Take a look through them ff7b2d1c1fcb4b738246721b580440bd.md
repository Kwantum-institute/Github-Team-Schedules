# IYNA Bootcamp Slides - Take a look through them

Assignee: Bonnie Wong
Status: In progress
Parent-task: General Research Stage 1 (General%20Research%20Stage%201%20184a53b7bed44dbea4608c4e2f656623.md)
Priority: Medium
Task ID: KIH-38

## Description

-