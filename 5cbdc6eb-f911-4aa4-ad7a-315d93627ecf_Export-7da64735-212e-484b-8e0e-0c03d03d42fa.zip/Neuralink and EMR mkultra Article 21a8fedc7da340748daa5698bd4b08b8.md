# Neuralink and EMR/ mkultra Article

Assignee: Shadow 1103
Status: In progress
Summary: No content
Due: February 14, 2024
Project: Adrian’s Blog (https://www.notion.so/Adrian-s-Blog-a567e68887e84a398b9da2ac781add13?pvs=21)
Sprint: Sprint 1 (https://www.notion.so/Sprint-1-b1a8ecea433044d6baf9bf296b85e4e0?pvs=21)
Sub-tasks: MKUltra summary 1 paragraph:  (MKUltra%20summary%201%20paragraph%205c531738fe704281bd9d8666fa3f00e8.md), Calcium battery: site SCMP MLA format (Calcium%20battery%20site%20SCMP%20MLA%20format%20c45445fedb154ddd8d64bab9c32a0546.md), EMR and biocomputers (EMR%20and%20biocomputers%202185d89b7a6e4f428311d7f0601b8eec.md), How Neurallink works (How%20Neurallink%20works%206be5f46df73f4597b503aba3cf42faab.md), Research planning  (Research%20planning%20ce34447750484c5da15f2d68f7d9dadd.md), Biohacking: Elon Musk statements (Biohacking%20Elon%20Musk%20statements%20f66c422e48f54c80b93186d454128320.md), How Neurons Work (How%20Neurons%20Work%20713312bf8f424166937bf9d861a6f1d4.md), Primary Function of Neuralink (Primary%20Function%20of%20Neuralink%20dd814a3de0ef422d834d7e3b809f1c3d.md), CRISPER (CRISPER%2058f5ae1fcb5448099b92b28c544c3c13.md), Neuralink accessory implants (Neuralink%20accessory%20implants%20b88bb99795a045938e371c3d1f796a42.md), Theoretical breakthroughs in science related to Neuralink (Theoretical%20breakthroughs%20in%20science%20related%20to%20Ne%2061fc3f35ad1d49a5ac10153a5445e353.md)
Priority: Medium
Task ID: KIH-8

## Description

- Materials:
- 

[CIA-RDP96-00788R001700210016-5.pdf](CIA-RDP96-00788R001700210016-5.pdf)

[IMG_3509.JPG](IMG_3509.jpg)