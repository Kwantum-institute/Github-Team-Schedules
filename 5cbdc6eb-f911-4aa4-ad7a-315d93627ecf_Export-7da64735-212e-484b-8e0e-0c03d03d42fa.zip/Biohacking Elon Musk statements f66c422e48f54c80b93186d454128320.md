# Biohacking: Elon Musk statements

Status: In progress
Project: Adrian’s Blog (https://www.notion.so/Adrian-s-Blog-a567e68887e84a398b9da2ac781add13?pvs=21)
Parent-task: Neuralink and EMR/ mkultra Article   (Neuralink%20and%20EMR%20mkultra%20Article%2021a8fedc7da340748daa5698bd4b08b8.md)
Task ID: KIH-65

## Description

- [https://www.forbes.com/health/wellness/biohacking/](https://www.forbes.com/health/wellness/biohacking/)
-