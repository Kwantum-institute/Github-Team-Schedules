# Wave Theory

Assignee: Timothy Ka
Status: In progress
Summary: This document provides instructions for inviting team members to collaborate on a task. Use the Share menu to invite team members and assign tasks using the "Assignee" field. Team members will receive a notification in their sidebar.
Due: March 5, 2024
Project: Modern Physics (https://www.notion.so/Modern-Physics-f74a4820ec6b45f6b7166faf5fa93607?pvs=21)
Sprint: Sprint 1 (https://www.notion.so/Sprint-1-b1a8ecea433044d6baf9bf296b85e4e0?pvs=21)
Priority: High
Task ID: KIH-2

- Ready to collaborate with your team? Use the Share menu at the top right.
- Use the “Assignee” field above to assign tasks to your teammates. They’ll see a notification in their sidebar.