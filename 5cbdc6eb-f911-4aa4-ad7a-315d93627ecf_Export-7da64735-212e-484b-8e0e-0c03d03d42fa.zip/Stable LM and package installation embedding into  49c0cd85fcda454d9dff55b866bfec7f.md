# Stable LM and package installation/ embedding into VS code

Status: Not started
Parent-task: Uncensored GPT (Uncensored%20GPT%2088e7ff2ef7e74fb7ac1d7e9cd139af72.md)
Task ID: KIH-168

## Description

-