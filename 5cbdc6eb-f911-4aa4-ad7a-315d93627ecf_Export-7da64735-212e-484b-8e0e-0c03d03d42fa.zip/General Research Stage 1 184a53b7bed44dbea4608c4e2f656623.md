# General Research Stage 1

Assignee: Bonnie Wong, Bonnie Wong
Status: Not started
Project:  Neuroscience Learning Series - Article (https://www.notion.so/Neuroscience-Learning-Series-Article-ca321b2bcd8b4628b80befba9213dd9c?pvs=21)
Sub-tasks:  ‘Cognitive Neuroscience’ - Read + Annotate (%E2%80%98Cognitive%20Neuroscience%E2%80%99%20-%20Read%20+%20Annotate%200670fc8d47524d468477ad9128062c0f.md), ‘Hallmark of Neurodegenerative Diseases’ - Read, Analyse, Annotate (%E2%80%98Hallmark%20of%20Neurodegenerative%20Diseases%E2%80%99%20-%20Read,%20A%20159ae2bec31f4f6094ceba9bc6841a4f.md), ‘Amyloid-β Peptide Protects Against Microbial Infection In Mouse and Worm Models of Alzheimer’s Disease’ - Pick, Read, Annotate on iPad (%E2%80%98Amyloid-%CE%B2%20Peptide%20Protects%20Against%20Microbial%20Infe%20a5c9219757814fe9bfd7b60c08d3d449.md), IYNA Bootcamp Slides - Take a look through them (IYNA%20Bootcamp%20Slides%20-%20Take%20a%20look%20through%20them%20ff7b2d1c1fcb4b738246721b580440bd.md)
Priority: Medium
Task ID: KIH-21

## Description

-