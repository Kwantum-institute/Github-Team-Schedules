# AI and Data science 2024 Update

Status: In progress
Summary: No content
Project: Adrian’s Blog (https://www.notion.so/Adrian-s-Blog-a567e68887e84a398b9da2ac781add13?pvs=21)
Sub-tasks: February AI Secret (February%20AI%20Secret%2009630987a3bd43bb9fefaec828200c73.md), Article ideas (Article%20ideas%203296621cb8104886904450cc885b10bc.md)
Task ID: KIH-155