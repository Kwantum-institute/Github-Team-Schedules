# Create XOR and AND gate

Status: Done
Project: Daniel Wong - 8 Bit Relay Adder (https://www.notion.so/Daniel-Wong-8-Bit-Relay-Adder-93ea4650e0854bac853b572561aeb924?pvs=21)
Task ID: KIH-54

## Description

-