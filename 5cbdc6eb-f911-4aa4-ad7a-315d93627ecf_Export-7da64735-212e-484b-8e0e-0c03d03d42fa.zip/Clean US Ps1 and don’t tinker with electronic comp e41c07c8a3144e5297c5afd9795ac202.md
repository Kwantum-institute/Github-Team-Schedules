# Clean US Ps1 and don’t tinker with electronic components

Assignee: Shadow 1103
Status: Not started
Project: Adrian’s Blog (https://www.notion.so/Adrian-s-Blog-a567e68887e84a398b9da2ac781add13?pvs=21)
Priority: Low
Task ID: KIH-171

## Description

-