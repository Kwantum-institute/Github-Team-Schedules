# General Research Stage 2

Assignee: Bonnie Wong
Status: In progress
Project:  Neuroscience Learning Series - Article (https://www.notion.so/Neuroscience-Learning-Series-Article-ca321b2bcd8b4628b80befba9213dd9c?pvs=21)
Priority: Medium
Task ID: KIH-40

## Description

- Upon choosing a topic, get a general idea of the surrounding topics inc. the one. This is an exploration stage, so what you need to do is get familiarise with it — broad — it’s before the narrow down. Select some articles that you find specifically interesting.
- Mind you, only limit this to 1-2 days else it would be counterproductive. There are also other priorities.