# finish setup of Wen Ui

Status: Done
Project: Adrian’s Blog (https://www.notion.so/Adrian-s-Blog-a567e68887e84a398b9da2ac781add13?pvs=21)
Parent-task: Uncensored GPT (Uncensored%20GPT%2088e7ff2ef7e74fb7ac1d7e9cd139af72.md)
Task ID: KIH-166

## Description

-