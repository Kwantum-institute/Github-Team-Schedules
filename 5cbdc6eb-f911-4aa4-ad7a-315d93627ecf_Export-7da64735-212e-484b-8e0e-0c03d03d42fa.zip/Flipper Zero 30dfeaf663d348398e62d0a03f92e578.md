# Flipper Zero

Status: In progress
Project: Adrian’s Blog (https://www.notion.so/Adrian-s-Blog-a567e68887e84a398b9da2ac781add13?pvs=21)
Task ID: KIH-159

## Description

- Flipper Zero is a portable Tamagotchi-like multi-functional device developed for interaction with access control systems. The device is able to read, copy, and emulate radio-frequency tags, radio remotes, and digital access keys.
- [https://github.com/Flipper-XFW/Xtreme-Firmware/wiki](https://github.com/Flipper-XFW/Xtreme-Firmware/wiki)

[Flipper Zero Xtreme News Update!](https://www.youtube.com/watch?v=kNLlvTB5zHs)

- Basic functions:
    - [https://youtube.com/shorts/u-gNA8Zsuhk?si=IXejB3UG2phoDIK_](https://youtube.com/shorts/u-gNA8Zsuhk?si=IXejB3UG2phoDIK_)
    -