# ‘Hallmark of Neurodegenerative Diseases’ - Read, Analyse, Annotate

Assignee: Bonnie Wong
Status: Not started
Parent-task: General Research Stage 1 (General%20Research%20Stage%201%20184a53b7bed44dbea4608c4e2f656623.md)
Priority: Optional
Task ID: KIH-36

## Description

- Website:

[](https://www.cell.com/cell/pdf/S0092-8674(22)01575-6.pdf)